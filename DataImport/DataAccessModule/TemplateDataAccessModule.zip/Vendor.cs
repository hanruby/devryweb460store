﻿using System;

namespace DataAccessModule
{
    [Serializable]
    public class Vendor
    {
        public int VendorID { get; set; }
        public string VendorName { get; set; }
    }
}
